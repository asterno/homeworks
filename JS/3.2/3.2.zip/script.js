let x = alert("Загадай число от 1 до 10")

let que1 = prompt("Увеличь его в 5 раз")


let que2 = prompt("Прибавь задуманное число и запииш в окошко")


let que3 = alert("Раздели 6")
b = que2 / 6

let an = alert(b)
