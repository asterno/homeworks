let arr = [ 1,2,3,4,5,6]




 arr.push(7);
 arr.pop(7);
 arr.shift(1);
 arr.unshift(1)


for(let i = 0;  i < arr.length; i++) {
    console.log(arr[i])
}



